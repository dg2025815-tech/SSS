# Human Cognitive Performance 데이터 분석 앱

## Streamlit Community Cloud 배포

1. GitHub 저장소에 `app.py`와 `requirements.txt`를 업로드합니다.
2. https://share.streamlit.io/ 에 접속해 GitHub 계정을 연결합니다.
3. **New app**을 선택하고 저장소와 브랜치, 메인 파일 경로(`app.py`)를 지정합니다.
4. **Deploy**를 누르면 앱이 실행됩니다.

앱은 기본적으로 제공된 GitHub Raw CSV 주소에서 데이터를 불러옵니다.
데이터 주소에 접근할 수 없으면 사이드바에서 CSV 파일을 직접 업로드할 수 있습니다.

## 포함 기능
- 데이터 미리보기 및 열별 데이터 유형 확인
- 결측치 유지 / 행 삭제 / 중앙값·최빈값 대체
- 중복 행 제거
- IQR 기준 이상치 행 제거
- 히스토그램, 박스 플롯, 산점도, 상관관계 히트맵, 범주형 빈도 그래프, 바이올린 플롯
- 전처리 전후 비교 및 정제 CSV 다운로드
