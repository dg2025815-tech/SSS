import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

DEFAULT_URL = "https://raw.githubusercontent.com/dg2025815-tech/ssss/refs/heads/main/human_cognitive_performance.csv"

st.set_page_config(
    page_title="Human Cognitive Performance 분석",
    page_icon="🧠",
    layout="wide"
)

st.title("🧠 Human Cognitive Performance 데이터 분석")
st.caption("데이터 불러오기 · 전처리 · 탐색적 데이터 분석 · Plotly 시각화")

@st.cache_data(show_spinner="데이터를 불러오는 중입니다...")
def load_from_url(url: str) -> pd.DataFrame:
    # GitHub Raw CSV 주소를 pandas로 읽습니다.
    return pd.read_csv(url)

@st.cache_data(show_spinner=False)
def load_from_upload(file_bytes: bytes) -> pd.DataFrame:
    from io import BytesIO
    return pd.read_csv(BytesIO(file_bytes))

def make_numeric(df):
    return df.select_dtypes(include=np.number).columns.tolist()

def make_categorical(df):
    return df.select_dtypes(include=["object", "category", "bool"]).columns.tolist()

with st.sidebar:
    st.header("📂 데이터 불러오기")
    source = st.radio("데이터 출처", ["GitHub URL", "CSV 파일 업로드"])
    uploaded = None
    url = DEFAULT_URL
    if source == "GitHub URL":
        url = st.text_input("CSV URL", value=DEFAULT_URL)
        load_clicked = st.button("URL에서 데이터 불러오기", type="primary", use_container_width=True)
    else:
        uploaded = st.file_uploader("CSV 파일 선택", type=["csv"])
        load_clicked = uploaded is not None

    st.divider()
    st.header("🧹 전처리 설정")
    missing_method = st.selectbox(
        "결측치 처리",
        ["유지", "결측치가 있는 행 삭제", "숫자형: 중앙값 / 문자형: 최빈값 대체"]
    )
    remove_duplicates = st.checkbox("중복 행 제거", value=True)
    remove_outliers = st.checkbox("숫자형 이상치(IQR 기준) 행 제거", value=False)
    st.caption("이상치 제거는 선택한 숫자형 열 중 하나라도 IQR 범위를 벗어나면 해당 행을 제외합니다.")

# 최초 접속 시 URL을 자동으로 불러옵니다.
if "raw_df" not in st.session_state:
    try:
        st.session_state.raw_df = load_from_url(DEFAULT_URL)
        st.session_state.load_error = None
    except Exception as e:
        st.session_state.raw_df = None
        st.session_state.load_error = str(e)

if source == "GitHub URL" and load_clicked:
    try:
        st.session_state.raw_df = load_from_url(url.strip())
        st.session_state.load_error = None
    except Exception as e:
        st.session_state.load_error = str(e)

if source == "CSV 파일 업로드" and uploaded is not None:
    try:
        st.session_state.raw_df = load_from_upload(uploaded.getvalue())
        st.session_state.load_error = None
    except Exception as e:
        st.session_state.load_error = str(e)

if st.session_state.get("raw_df") is None:
    st.error("데이터를 불러오지 못했습니다.")
    if st.session_state.get("load_error"):
        st.code(st.session_state.load_error)
    st.info("GitHub URL을 확인하거나 CSV 파일을 직접 업로드해 주세요.")
    st.stop()

raw_df = st.session_state.raw_df.copy()
if raw_df.empty:
    st.warning("CSV에 데이터가 없습니다.")
    st.stop()

st.success(f"데이터 불러오기 완료: {raw_df.shape[0]:,}행 × {raw_df.shape[1]:,}열")

# ---------------- 전처리 ----------------
df = raw_df.copy()
original_rows = len(df)

if missing_method == "결측치가 있는 행 삭제":
    df = df.dropna()
elif missing_method == "숫자형: 중앙값 / 문자형: 최빈값 대체":
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            if df[col].notna().any():
                df[col] = df[col].fillna(df[col].median())
        else:
            modes = df[col].mode(dropna=True)
            if not modes.empty:
                df[col] = df[col].fillna(modes.iloc[0])

if remove_duplicates:
    df = df.drop_duplicates()

numeric_cols = make_numeric(df)
categorical_cols = make_categorical(df)

with st.sidebar:
    st.subheader("이상치 제거 열")
    outlier_cols = st.multiselect(
        "IQR 기준을 적용할 숫자형 열",
        options=numeric_cols,
        default=numeric_cols
    ) if numeric_cols else []

if remove_outliers and outlier_cols:
    keep = pd.Series(True, index=df.index)
    for col in outlier_cols:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        keep &= df[col].between(lower, upper) | df[col].isna()
    df = df.loc[keep].copy()

numeric_cols = make_numeric(df)
categorical_cols = make_categorical(df)

# ---------------- 요약 ----------------
st.subheader("1. 데이터 미리보기")
m1, m2, m3, m4 = st.columns(4)
m1.metric("원본 행 수", f"{len(raw_df):,}")
m2.metric("전처리 후 행 수", f"{len(df):,}", delta=f"{len(df)-original_rows:+,}")
m3.metric("열 수", f"{df.shape[1]:,}")
m4.metric("남은 결측치", f"{int(df.isna().sum().sum()):,}")

tab1, tab2, tab3, tab4 = st.tabs(["데이터", "결측치·기초통계", "시각화", "전처리 결과"])

with tab1:
    st.dataframe(df.head(100), use_container_width=True)
    with st.expander("열 이름과 데이터 유형"):
        schema = pd.DataFrame({
            "열 이름": df.columns,
            "데이터 유형": [str(t) for t in df.dtypes],
            "결측치 수": df.isna().sum().values,
            "고유값 수": df.nunique(dropna=True).values
        })
        st.dataframe(schema, use_container_width=True)

with tab2:
    left, right = st.columns(2)
    with left:
        st.markdown("**열별 결측치 수**")
        missing = df.isna().sum().sort_values(ascending=False)
        missing = missing[missing > 0]
        if len(missing):
            miss_df = missing.rename_axis("열").reset_index(name="결측치 수")
            fig = px.bar(miss_df, x="열", y="결측치 수", title="열별 결측치")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("현재 데이터에 결측치가 없습니다.")
    with right:
        st.markdown("**숫자형 변수 기초통계**")
        if numeric_cols:
            st.dataframe(df[numeric_cols].describe().T, use_container_width=True)
        else:
            st.info("숫자형 열이 없습니다.")

with tab3:
    st.markdown("### 분포 및 변수 관계")
    if not numeric_cols and not categorical_cols:
        st.info("시각화할 수 있는 열이 없습니다.")
    else:
        chart_type = st.selectbox(
            "그래프 종류",
            ["히스토그램", "박스 플롯", "산점도", "상관관계 히트맵", "범주형 빈도 막대그래프", "바이올린 플롯"]
        )

        if chart_type == "히스토그램":
            if numeric_cols:
                col = st.selectbox("분석할 숫자형 변수", numeric_cols, key="hist_col")
                bins = st.slider("구간 수", 5, 100, 30)
                fig = px.histogram(df, x=col, nbins=bins, marginal="box",
                                   title=f"{col} 분포")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("숫자형 열이 없습니다.")

        elif chart_type == "박스 플롯":
            if numeric_cols:
                col = st.selectbox("숫자형 변수", numeric_cols, key="box_col")
                group_options = ["그룹화하지 않음"] + categorical_cols
                group = st.selectbox("그룹 변수(선택)", group_options, key="box_group")
                fig = px.box(df, y=col, x=None if group == "그룹화하지 않음" else group,
                             points="outliers", title=f"{col} 박스 플롯")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("숫자형 열이 없습니다.")

        elif chart_type == "산점도":
            if len(numeric_cols) >= 2:
                xcol = st.selectbox("X축", numeric_cols, index=0, key="scatter_x")
                y_options = [c for c in numeric_cols if c != xcol]
                ycol = st.selectbox("Y축", y_options, key="scatter_y")
                color_options = ["사용 안 함"] + categorical_cols
                color_col = st.selectbox("색상 구분", color_options, key="scatter_color")
                fig = px.scatter(
                    df, x=xcol, y=ycol,
                    color=None if color_col == "사용 안 함" else color_col,
                    hover_data=df.columns[:min(5, len(df.columns))],
                    title=f"{xcol}와 {ycol}의 관계"
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("산점도에는 숫자형 열이 최소 2개 필요합니다.")

        elif chart_type == "상관관계 히트맵":
            if len(numeric_cols) >= 2:
                corr = df[numeric_cols].corr(numeric_only=True)
                fig = px.imshow(corr, text_auto=".2f", aspect="auto",
                                color_continuous_scale="RdBu_r",
                                zmin=-1, zmax=1, title="숫자형 변수 상관관계")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("상관관계 분석에는 숫자형 열이 최소 2개 필요합니다.")

        elif chart_type == "범주형 빈도 막대그래프":
            if categorical_cols:
                col = st.selectbox("범주형 변수", categorical_cols, key="cat_col")
                top_n = st.slider("표시할 범주 수", 5, 50, 20)
                counts = df[col].fillna("(결측)").astype(str).value_counts().head(top_n)
                plot_df = counts.rename_axis(col).reset_index(name="빈도")
                fig = px.bar(plot_df, x=col, y="빈도", title=f"{col} 범주별 빈도")
                fig.update_layout(xaxis_tickangle=-35)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("범주형 열이 없습니다.")

        elif chart_type == "바이올린 플롯":
            if numeric_cols:
                col = st.selectbox("숫자형 변수", numeric_cols, key="violin_col")
                group_options = ["그룹화하지 않음"] + categorical_cols
                group = st.selectbox("그룹 변수(선택)", group_options, key="violin_group")
                fig = px.violin(df, y=col,
                                x=None if group == "그룹화하지 않음" else group,
                                box=True, points="all",
                                title=f"{col} 바이올린 플롯")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("숫자형 열이 없습니다.")

with tab4:
    st.markdown("### 전처리 전후 비교")
    compare = pd.DataFrame({
        "항목": ["행 수", "열 수", "결측치 개수", "중복 행 개수"],
        "전처리 전": [
            len(raw_df), raw_df.shape[1],
            int(raw_df.isna().sum().sum()),
            int(raw_df.duplicated().sum())
        ],
        "전처리 후": [
            len(df), df.shape[1],
            int(df.isna().sum().sum()),
            int(df.duplicated().sum())
        ]
    })
    st.dataframe(compare, use_container_width=True)
    st.markdown("### 전처리된 데이터 다운로드")
    csv_bytes = df.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "전처리된 CSV 다운로드",
        data=csv_bytes,
        file_name="human_cognitive_performance_cleaned.csv",
        mime="text/csv",
        type="primary"
    )

st.divider()
st.caption("참고: 전처리 옵션을 바꾸면 현재 원본 데이터에 설정이 다시 적용됩니다. 원본 CSV는 수정되지 않습니다.")
